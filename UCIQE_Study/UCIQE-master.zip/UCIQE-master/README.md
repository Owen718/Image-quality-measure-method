See UCIQE.m
