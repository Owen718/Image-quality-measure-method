clear all
clc

im = imread('1.bmp');    
   
quality = CCF(im)